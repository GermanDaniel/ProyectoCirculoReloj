/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista;
import negocio.nodo;
import negocio.nodoLD;
/**
 *
 * @author pc
 */
public class clsListaDoble {
    private nodoLD pListaD;
    public clsListaDoble(){
        this.pListaD = null;
    }
    
    public void setpListaD(nodoLD pListaD){
        this.pListaD = pListaD;
    }
    
    public nodoLD getpListaD(){
        return this.pListaD;
    }
    
    public void insertarIzq(int dato){
        nodoLD nn = new nodoLD(dato);
        if(this.pListaD == null){
            this.pListaD = nn;
        }else{
            if(this.pListaD.getRefIzq() == null){
                nn.setRefDer(this.pListaD);
                this.pListaD.setRefIzq(nn);
            }else{
                (this.pListaD.getRefIzq()).setRefDer(nn);
                nn.setRefIzq(this.pListaD.getRefIzq());
                nn.setRefDer(this.pListaD);
                this.pListaD.setRefIzq(nn);
            }
        }
    }
    public void eliminarValor(int valor){
        if (this.pListaD != null){
            nodoLD aux = this.pListaD;
            nodoLD ant = null;
            while (aux != null){
                if(aux.getDato() == valor){
                    if (ant == null){
                        this.pListaD = this.pListaD.getRefIzq();
                        aux.setRefIzq(null);
                        aux= this.pListaD;
            }else{
                ant.setRefIzq(aux.getRefIzq());
                aux.setRefIzq(null);
                aux = ant.getRefIzq();
            }                                             
            }else{
            ant = aux;
            aux = aux.getRefIzq();
                }
            }
        }                          
    }
    
    public int cantidad(){
        int a=0;
        nodoLD pop = pListaD;
        while(pop.getRefIzq() != null){
            a++;
            pop=pop.getRefIzq();
        }
        if(pop.getRefIzq() == null) a++;
        return a;
    }
    
    public boolean moverDer(){
        if(this.pListaD.getRefDer() != null){
            this.pListaD = this.pListaD.getRefDer();
            return true;
        }else{
            return false;
        }
    }
    
    public boolean moverIzq(){
        if(this.pListaD.getRefIzq() != null){
            this.pListaD = this.pListaD.getRefIzq();
            return true;
        }else{
            return false;
        }
    }
    
    public void irPrimero(){
        while(moverIzq()){
            ;
        }
    }
    
    public void irUltimo(){
        while(moverDer()){
            ;
        }
    }
}
