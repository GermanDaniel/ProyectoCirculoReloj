/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lista;
import negocio.nodoLD;
/**
 *
 * @author pc
 */
public class clsListaCircular {
    private nodoLD PLC;
    
    public clsListaCircular(){
        this.PLC = null;
    }

    public nodoLD getPLC() {
        return PLC;
    }

    public void setPLC(nodoLD PLC) {
        this.PLC = PLC;
    }
      
    /*public void insertarDerecha(int dato){
        nodoLD nn = new nodoLD(dato);
        if(this.PLC == null){
            this.PLC = nn;
            this.PLC.setRefDer(this.PLC);
            this.PLC.setRefIzq(this.PLC);
        }else{
            (this.PLC.getRefDer()).setRefIzq(nn);
            nn.setRefDer(this.PLC.getRefDer());
            this.PLC.setRefDer(nn);
            nn.setRefIzq(this.PLC);
        }
    }*/
    
    public void insertarDerecha(int dato){
    nodoLD nn = new nodoLD(dato);
        if(this.PLC == null){
            this.PLC = nn;
        }else{
            if(this.PLC.getRefIzq() == null){
                nn.setRefDer(this.PLC);
                this.PLC.setRefIzq(nn);
            }else{
                (this.PLC.getRefIzq()).setRefDer(nn);
                nn.setRefIzq(this.PLC.getRefIzq());
                nn.setRefDer(this.PLC);
                this.PLC.setRefIzq(nn);
            }
        }
    }
    
    public void EliminarNodo(int valor){
        if (this.PLC != null){
            nodoLD aux = this.PLC;
            nodoLD ant = null;
            while (aux != null){
                if(aux.getDato() == valor){
                    if (ant == null){
                        this.PLC = this.PLC.getRefIzq();
                        aux.setRefIzq(null);
                        aux= this.PLC;
            }else{
                ant.setRefIzq(aux.getRefIzq());
                aux.setRefIzq(null);
                aux = ant.getRefIzq();
            }                                             
            }else{
            ant = aux;
            aux = aux.getRefIzq();
                }
            }
        }                          
    }
    
    public int cantidadNodos(){
        int a=0;
        nodoLD pop = PLC;
        while(pop.getRefIzq() != null){
            a++;
            pop=pop.getRefIzq();
        }
        if(pop.getRefIzq() == null) a++;
        return a;
    }
    
    public boolean estaVacia(){
        if(this.PLC == null){
            return true;
        }else{
            return false;
        }
    }
    
    public boolean esUnSoloNodo(){
        if(this.PLC == this.PLC.getRefDer() && this.PLC == this.PLC.getRefIzq()){
            return true;
        }else{
            return false;
        }
    }
    
    public void eliminarDerecha(){
        if(!estaVacia()){
            if(esUnSoloNodo()){
                this.PLC = null;
            }else{
                ((this.PLC.getRefDer()).getRefDer()).setRefIzq(this.PLC);
                this.PLC.setRefDer((this.PLC.getRefDer()).getRefDer());
            }
        }
    }
}
